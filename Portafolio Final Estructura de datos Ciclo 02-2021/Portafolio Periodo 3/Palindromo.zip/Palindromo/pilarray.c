/* 	   Archivo pilarray.c
  Implementaci�n de operaciones sobre pilas 
*/

typedef char TipoDato;

#include "pilarray.h"

	/* Inicializa la pila a pila vac�a */
void CrearPila(Pila* P)
{
  P -> cima = -1;
}

/* poner un elemento en la pila */

void Insertar(Pila* P,const TipoDato elemento)
{
	 /* si la pila est� llena, termina el programa */
	if (P->cima == MaxTamaPila-1)
	{
		puts("Desbordamiento pila");
		exit (1);
	}

	/* incrementar puntero cima y copiar elemento en listapila */
	P->cima++;
	P->listapila[P->cima] = elemento;
}

/* Quitar un elemento de la pila */

TipoDato Quitar(Pila* P)
{
	TipoDato Aux;
	/* si la pila est� vac�a, termina el programa  */
	if (P->cima == -1)
	{
		puts("Se intenta sacar un elemento en pila vac�a");
		exit (1);
	}

	  /* guardar elemento de la cima */
	Aux = P->listapila[P->cima];

	  /* decrementar cima y devolver valor del elemento */
	P->cima--;
	return Aux;
}

/* verificar pila vac�a */

int PilaVacia(Pila P)
{   /*devuelve el valor l�gico resultante de expresi�n cima == -1 */
	return P.cima == -1;
}

  /* verificar si la pila est� llena */

int PilaLlena(Pila P)
{

	return P.cima == MaxTamaPila-1;
}
/* quitar todos los elementos de la pila */
void LimpiarPila(Pila* P)
{
	P->cima = -1;
}
TipoDato Cima(Pila P)
{
  if (P.cima == -1)
  {
    puts("Se intenta sacar un elemento en pila vac�a");
    exit (1);
  }
  return  P.listapila[P.cima];
}

