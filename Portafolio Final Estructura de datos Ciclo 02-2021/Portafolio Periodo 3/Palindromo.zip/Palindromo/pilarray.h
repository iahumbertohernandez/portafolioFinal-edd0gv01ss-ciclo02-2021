/* Archivo pilarray.h */

#include <stdio.h>
#include <stdlib.h>

#define MaxTamaPila 100

typedef struct
{
	TipoDato listapila[MaxTamaPila];
	int cima;
} Pila;

	/* Operaciones sobre la Pila */

void CrearPila(Pila* P);
void Insertar(Pila* P,const TipoDato elemento);
TipoDato Quitar(Pila* P);
void LimpiarPila(Pila* P);

	/* Operaci�n de acceso a Pila */

TipoDato Cima(Pila P);

	/* verificaci�n estado de la Pila */

int PilaVacia(Pila P);
int PilaLlena(Pila P);

